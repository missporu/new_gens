<style>
/*
 * Globals
 */
h1 { color: #fff !important; }
p { color: #fff; }
/* Links */
a,
a:focus,
a:hover {
  color: #fff;
}

/* Custom default button */
.btn-default,
.btn-default:hover,
.btn-default:focus {
  color: #333;
  text-shadow: none; /* Prevent inheritence from `body` */
  background-color: #fff;
  border: 1px solid #fff;
}


/*
 * Base structure
 */

html,
body {
  height: 100%;
  background-color: #000;
}
body {
	background-image: url(images/videoplayback.jpg);
	background-size: cover;
  color: #fff;
  text-align: center;
  text-shadow: 0 1px 3px rgba(0,0,0,.5);
  box-shadow: inset 0 0 100px rgba(0,0,0,.5);
}

/* Extra markup and styles for table-esque vertical and horizontal centering */
.site-wrapper {
  display: table;
  width: 100%;
  height: 100%; /* For at least Firefox */
  min-height: 100%;
}
.site-wrapper-inner {
  display: table-cell;
  vertical-align: top;
}
.cover-container {
  margin-right: auto;
  margin-left: auto;
}

/* Padding for spacing */
.inner {
  padding: 30px;
}


/*
 * Header
 */
.masthead-brand {
  margin-top: 10px;
  margin-bottom: 10px;
}

.masthead-nav > li {
  display: inline-block;
}
.masthead-nav > li + li {
  margin-left: 20px;
}
.masthead-nav > li > a {
  padding-right: 0;
  padding-left: 0;
  font-size: 16px;
  font-weight: bold;
  color: #fff; /* IE8 proofing */
  color: rgba(255,255,255,.75);
  border-bottom: 2px solid transparent;
}
.masthead-nav > li > a:hover,
.masthead-nav > li > a:focus {
  background-color: transparent;
  border-bottom-color: rgba(255,255,255,.25);
}
.masthead-nav > .active > a,
.masthead-nav > .active > a:hover,
.masthead-nav > .active > a:focus {
  color: #fff;
  border-bottom-color: #fff;
}

@media (min-width: 768px) {
  .masthead-brand {
    float: left;
  }
  .masthead-nav {
    float: right;
  }
}


/*
 * Cover
 */

.cover {
  padding: 0 20px;
}
.cover .btn-lg {
  padding: 10px 20px;
  font-weight: bold;
}


/*
 * Footer
 */

.mastfoot {
  color: #999; /* IE8 proofing */
  color: rgba(255,255,255,.5);
}


/*
 * Affix and center
 */

@media (min-width: 768px) {
  /* Pull out the header and footer */
  .masthead {
    position: fixed;
    top: 0;
  }
  .mastfoot {
    position: fixed;
    bottom: 0;
  }
  /* Start the vertical centering */
  .site-wrapper-inner {
    vertical-align: middle;
  }
  /* Handle the widths */
  .masthead,
  .mastfoot,
  .cover-container {
    width: 100%; /* Must be percentage or pixels for horizontal alignment */
  }
}

@media (min-width: 992px) {
  .masthead,
  .mastfoot,
  .cover-container {
    width: 700px;
  }
}
</style>
﻿<?php
require_once('./system/up.php');
_NoReg();
if (isset($_POST['send'])) {
    $name = _TextFilter($_POST['login']);
    $pass = md5(_TextFilter($_POST['pass']));
    $sql  = _NumRows("SELECT `login`, `pass` FROM `user_reg` WHERE `login`='" . $name . "' AND `pass`='" . $pass . "' LIMIT 1");
    if (empty($name)) {
        $_SESSION['err'] = 'Введите логин';
        header('Location: login.php');
        exit();
    } elseif (empty($pass)) {
        $_SESSION['err'] = 'Введите пароль';
        header('Location: login.php');
        exit();
    } elseif ($sql == 0) {
        $_SESSION['err'] = 'Игрок не найден';
        $_SESSION['rec'] = '<br/><br/><a href="rec.php"><span class="btn"><span class="end"><input class="label" type="submit" value="Забыт пароль"/></span></span></a>';
        header('Location: login.php');
        exit();
    } else {
        setcookie('login', $name, time() + 86400 * 365, '/');
        setcookie('pass', $pass, time() + 86400 * 365, '/');
        header('Location: bonus.php');
        exit();
    }
}
?>
<style>
body {background-color: #999; }
</style>
<div class="container">
    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="inner cover">
            <h1 class="cover-heading">Генералы</h1>
            <p class="lead">Oнлайн игра для твоего мобильного!</p>
            <p class="lead">Построй свою армию и приведи её к победе любыми способами!</p>
            <p>Тысячи генералов уже ведут военные действия! Не упусти свой шанс!</p>
            <p class="lead">
              	<a href="login.php" class="btn btn-lg btn-default">Войти </a>
					<a href="reg.php" class="btn btn-lg btn-default">Начать новую игру</a>
            </p>
          </div>

          <div class="mastfoot">
            <div class="inner">
<div class="small grey"><center><a><a href="rules.php"><font color=#AAA>Правила игры </a><br>
              <p>Разработка сайтов - <a href="https://misspo.ru">misspo</a> &copy; 2016 - <?=date("Y");?>.</p>
            </div>
          </div>

        </div>

      </div>

    </div>
</div>
<!-- /.container -->

<?php
if (isset($_SESSION['rec'])) {
    echo '' . $_SESSION['rec'] . '';
    $_SESSION['rec'] = NULL;
}
?>


<?php
require_once('system/down.php');
?>
