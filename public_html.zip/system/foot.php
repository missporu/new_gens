<style>
#server_time {
    color: #fff;
    font-style: italic;
    font-weight: 600;
}
a.text-white {
    color: #fff;
    font-style: italic;
    font-weight: 500;
    text-decoration: none;
}
@-webkit-keyframes pulsate { 
50% { 
color: #fff; 
text-shadow: 0 -1px rgba(0,0,0,.3), 0 0 5px #ffd, 0 0 8px #fff; 
} 
} 
@keyframes pulsate { 50% { 
color: #fff; 
text-shadow: 0 -1px rgba(0,0,0,.3), 0 0 5px #ffd, 0 0 8px #fff; 
} } 
#blink7 { 
color: rgb(245,245,245); 
text-shadow: 0 -1px rgba(0,0,0,.1); 
-webkit-animation: pulsate 1.2s linear infinite; 
animation: pulsate 1.2s linear infinite; 
} 
</style>
<script> 
    function moscowTime() { 
        var d = new Date(); 
        d.setHours( d.getHours() + 3, d.getMinutes() + d.getTimezoneOffset()  );
        return d.toTimeString().substring(0,8); 
    } 
  
    onload = function () { 
  
    setInterval(function () { 
        document.getElementById("server_time").innerHTML = moscowTime();
    }, 100);} 
</script> 
<?php $date = date("d.m.Y"); ?>
<?php
if ($user) {
?>
<div class="block_zero center"><?php
$action_on = _FetchAssoc("SELECT * FROM `setting_game` WHERE `id`='1' LIMIT 1");
if  ($action_on['data_gold'] < time()) {
    mysql_query("UPDATE `setting_game` SET `action_gold`='0', `skolko_gold`='0', `data_gold`='0' WHERE `id`='1' LIMIT 1");
}
if ($set['premium'] == 1) { ?>
    <a href="bank.php?case=worldkassa"><b style="color: #fff">До конца премиума осталось <?= _Time($set['premium_time']-time()) ?> !</b></a> <br> <?php
}
$time_action_gold = $action_on['data_gold']-time();
if ($action_on['action_gold'] == 1) { ?>
    <a href="bank.php?case=worldkassa"><b style="color: #f0f">Акция! x<?= $action_on['skolko_gold'] ?> к золоту!</b></a> <?= _DayTime($time_action_gold) ?><br> <?php
} ?>
    <small>
        <a class="text-white" href="rules.php">Правила игры</a> | 
        <a class="text-white" href="mail.php?case=post&log=1">Письмо Админу</a> | 
        <a class="text-white" href="faq.php">Помощь</a> | 
        <a class="text-white" href="https://vk.com/generals_misspo">ВКонтакте</a></br>
        <a href="https://misspo.ru">misspo.ru</a> | 
<div id="blink7"><a href="http://l2.gmisspo.ru">Linages II - (игра-партнер)</a> |</div>
        
    </small>
    <div class="separ"></div>
    <span class="small grey"><?php echo round(microtime(1) - $timeregen, 4); ?> сек., </span>
        <?php echo'<span id="server_time">'.$time.'</span>  | <b style="color: #fff;">'.$date.'</b>'; ?> | 
    <a href="online.php">
    <span style="color: #fff;"><b>Онлайн: <?php echo mysql_result(mysql_query("SELECT COUNT(*) FROM `user_set` WHERE `online`> '".(time()-600)."'"), 0); ?></b></a>
</div>
<center>
    <a href="http://statok.net/go/19478"><img src="//statok.net/imageOther/19478" alt="Statok.net" /></a>
    <script type="text/javascript" src="https://mobtop.ru/c/121844.js"></script><noscript><a href="https://mobtop.ru/in/121844"><img src="https://mobtop.ru/121844.gif" alt="MobTop.Ru - Рейтинг и статистика мобильных сайтов"/></a></noscript>
    <br/>
</center>
<?php 
} else {
?>
<center>
    <div class="separ"></div>
    <span class="small grey">
        <?php echo round(microtime(1) - $timeregen, 4); ?> сек., 
        
        <?php echo'<span id="server_time">'.$time.'</span>  | '.$date.''; ?>  | <b style="color: #fff;">Онлайн: <?php echo mysql_result(mysql_query("SELECT COUNT(*) FROM `user_set` WHERE `online`> '".(time()-600)."'"), 0); ?></b>
    </span><br>
<a href="http://gmisspo.ru" onclick="javascript: return add_favorite(this);" title="Добавить в закладки">В закладки</a><br>
    <a href="http://statok.net/go/19478"><img src="//statok.net/image/19478" alt="Statok.net" /></a><br/>
    <script type="text/javascript" src="https://mobtop.ru/c/121843.js"></script><noscript><a href="https://mobtop.ru/in/121843"><img src="https://mobtop.ru/121843.gif" alt="MobTop.Ru - Рейтинг и статистика мобильных сайтов"/></a></noscript>
<br>
</center>
<?php 
}
mysql_close($mysql); ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="http://getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
