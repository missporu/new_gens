<?php
require_once('system/sys.php');
// mysql_query("UPDATE `user_set` SET `raiting` = `raiting`+1, `uho`=`uho`+3 WHERE `id`='680' ");
// mysql_query("UPDATE `user_set` SET `raiting` = `raiting`+1, `uho`=`uho`+3 WHERE `id`='74' ");
header("Location: index.php");
exit;